package loginsystem;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import loginsystem.Login; // Import the Login class
import javax.swing.JOptionPane; // Import the JOptionPane class

public class Main {

    public static void main(String[] args) {

        String firstname, lastname, username, password, phone;

        // Prompt and receive user inputs
        String registrationMessage = "-----------Register-----------";
        JOptionPane.showMessageDialog(null, registrationMessage);

        // Get user inputs via JOptionPane
        firstname = JOptionPane.showInputDialog("Enter First Name: ");
        lastname = JOptionPane.showInputDialog("Enter Last Name: ");
        username = JOptionPane.showInputDialog("Enter username: ");
        password = JOptionPane.showInputDialog("Enter Password: ");
        phone = JOptionPane.showInputDialog("Enter Phone Number (starting with South African international code (+27)): ");

        Login login = new Login(); // Instantiate Login object

        boolean validatePhone = login.checkCellPhoneNumber(phone);
        boolean validateUsername = login.checkUserName(username);
        boolean validatePassword = login.checkPasswordComplexity(password);

        // Check and validate username
        if (validateUsername) {
            JOptionPane.showMessageDialog(null, "Username successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted. Please ensure that your username contains an underscore and is not more than five characters in length.");
        }

        // Check and validate password
        if (validatePassword) {
            JOptionPane.showMessageDialog(null, "Password successfully captured.");
        } else {
            JOptionPane.showMessageDialog(null, "Password is incorrect. Please ensure that the password contains at least eight characters, a capital and small letter, a number, and a special character.");
        }

        // Check and validate phone number
        if (validatePhone) {
            JOptionPane.showMessageDialog(null, "Cellphone number successfully added.");
        } else {
            JOptionPane.showMessageDialog(null, "Cellphone number is incorrectly formatted or does not contain the international code.");
        }

        // If all validations pass, continue to login
        if (validateUsername && validatePassword && validatePhone) {
            JOptionPane.showMessageDialog(null, "You have registered successfully!");

            String loginUsername = JOptionPane.showInputDialog("Enter username: ");
            String loginPassword = JOptionPane.showInputDialog("Enter password: ");

            if (loginUsername.equals(username) && loginPassword.equals(password)) {
                JOptionPane.showMessageDialog(null, "Welcome " + firstname + " " + lastname + ", it is great to see you again.");
            } else {
                JOptionPane.showMessageDialog(null, "Login failed! Wrong username or password.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Failed to register.");
        }
    }
}

/**
 *
 * @author RC_Student_lab
 */
public class QuickChatGUI {

    private static boolean loggedIn = false;
    private static final List sentMessages = new ArrayList<>();
    private static int messageCounter = 0;

    public static void main(String[] args) {
        loginUser();

        JOptionPane.showMessageDialog(null, "Welcome to the ChatApp.", "Welcome", JOptionPane.INFORMATION_MESSAGE);

        int maxMessages = promptForMaxMessages();

        boolean running = true;
        while (running) {
            String menu = "Please choose an option:\n"
                    + "1) Send Messages\n"
                    + "2) Show recently sent messages\n"
                    + "3) Quit";

            String choice = JOptionPane.showInputDialog(null, menu, "Main Menu", JOptionPane.QUESTION_MESSAGE);

            if (choice == null) {
                // User pressed Cancel or closed dialog, treat as quit
                running = false;
                continue;
            }

            switch (choice.trim()) {
                case "1":
                    if (!loggedIn) {
                        JOptionPane.showMessageDialog(null, "You must be logged in to send messages.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        sendMessages(maxMessages);
                    }
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon.", "Info", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Goodbye!", "Exit", JOptionPane.INFORMATION_MESSAGE);
                    running = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please enter 1, 2, or 3.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void loginUser() {
        while (!loggedIn) {
            String username = JOptionPane.showInputDialog(null, "Enter username:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (username == null) {
                // User cancelled
                System.exit(0);
            }
            String password = JOptionPane.showInputDialog(null, "Enter password:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (password == null) {
                System.exit(0);
            }

            if (!username.trim().isEmpty() && !password.trim().isEmpty()) {
                loggedIn = true;
                JOptionPane.showMessageDialog(null, "Login successful.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Invalid login. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static int promptForMaxMessages() {
        int maxMessages = 0;
        while (maxMessages <= 0) {
            String input = JOptionPane.showInputDialog(null, "How many messages would you like to enter?", "Set Message Limit", JOptionPane.QUESTION_MESSAGE);
            if (input == null) {
                System.exit(0);
            }
            try {
                maxMessages = Integer.parseInt(input.trim());
                if (maxMessages <= 0) {
                    JOptionPane.showMessageDialog(null, "Please enter a positive number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Invalid number. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        return maxMessages;
    }

    private static void sendMessages(int maxMessages) {
        int messagesSent = 0;
        while (messagesSent < maxMessages) {
            String recipient = null;
            while (true) {
                recipient = JOptionPane.showInputDialog(null,
                        String.format("Enter recipient number (must start with '+' and max 15 characters)\nMessage %d of %d",
                                messagesSent + 1, maxMessages),
                        "Recipient Input", JOptionPane.QUESTION_MESSAGE);
                if (recipient == null) {
                    // User cancelled sending messages
                    return;
                }
                recipient = recipient.trim();
                if (validateRecipient(recipient)) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid recipient number. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

            String messageText = null;
            while (true) {
                messageText = JOptionPane.showInputDialog(null,
                        "Enter your message (max 250 characters):",
                        "Message Input", JOptionPane.QUESTION_MESSAGE);
                if (messageText == null) {
                    // User cancelled sending messages
                    return;
                }
                if (messageText.length() <= 250) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a message of less than 50 characters.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

            String messageID = generateUniqueMessageID();
            messageCounter++;

            String messageHash = generateMessageHash(messageID, messageCounter, recipient, messageText);

            Message msg = new Message(messageID, messageCounter, recipient, messageText, messageHash);
            sentMessages.add(msg);

            JOptionPane.showMessageDialog(null, "Message sent.", "Success", JOptionPane.INFORMATION_MESSAGE);

            messagesSent++;
        }
    }

    private static boolean validateRecipient(String recipient) {
        if (recipient.startsWith("+") && recipient.length() <= 15) {
            String numberPart = recipient.substring(1);
            return numberPart.matches("\\d+");
        }
        return false;
    }

    private static String generateUniqueMessageID() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    private static String generateMessageHash(String messageID, int msgNumber, String recipient, String message) {
        String input = messageID + msgNumber + recipient + message;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (Exception e) {
            return "";
        }
    }

    static class Message {
        String messageID;
        int messageNumber;
        String recipient;
        String message;
        String messageHash;

        public Message(String messageID, int messageNumber, String recipient, String message, String messageHash) {
            this.messageID = messageID;
            this.messageNumber = messageNumber;
            this.recipient = recipient;
            this.message = message;
            this.messageHash = messageHash;
        }

        @Override
        public String toString() {
            return String.format("ID: %s | Num: %d | Recipient: %s | Message: %s | Hash: %s",
                    messageID, messageNumber, recipient, message, messageHash);
        }
    }
}

